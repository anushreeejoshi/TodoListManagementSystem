package com.example.demo.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Task {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    // this is the primary key which will be auto generated
    private Long id;
    private String taskDet;
    private boolean completed;
  
    public Task(String taskDet, boolean completed) {
        this.taskDet = taskDet;
        this.completed = completed;
    }
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getTaskDet() {
        return taskDet;
    }
    public void setTaskDet(String taskDet) {
        this.taskDet = taskDet;
    }
    public boolean isCompleted() {
        return completed;
    }
    public void setCompleted(boolean completed) {
        this.completed = completed;
    }
	public Task() {
		
		// TODO Auto-generated constructor stub
	}
    
}