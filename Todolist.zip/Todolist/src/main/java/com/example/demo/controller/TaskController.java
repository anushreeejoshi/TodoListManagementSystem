package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.models.Task;
import com.example.demo.service.TaskService;


@Controller
@RequestMapping("/")
public class TaskController {
  
    @Autowired
    private TaskService taskService;
//    @GetMapping("/")
//    public ResponseEntity<List<Task>> getAllTasks() {
//        return ResponseEntity.ok(taskService.getAllTask());
//    }
    @GetMapping("/")
    public String getAllTasks(Model model) {
    	model.addAttribute("listTask",taskService.getAllTask());
    	return "index";
    }
//    @GetMapping("/completed")
//    public ResponseEntity<List<Task>> getAllCompletedTasks() {
//        return ResponseEntity.ok(taskService.findAllCompletedTask());
//    }
    @GetMapping("/completed")
    public String getAllCompletedTasks(Model model) {
    	model.addAttribute("listCompletedTask",taskService.findAllCompletedTask());
    	return "completed";
    }
//    @GetMapping("/incomplete")
//    public ResponseEntity<List<Task>> getAllIncompleteTasks() {
//        return ResponseEntity.ok(taskService.findAllInCompleteTask());
//    }
    
    @GetMapping("/incomplete")
    public String getAllIncompletedTasks(Model model) {
    	model.addAttribute("listIncompleteTask",taskService.findAllInCompleteTask());
    	return "incomplete";
    }
//    @PostMapping("/")
//    public ResponseEntity<Task> createTask(@RequestBody Task task) {
//        return ResponseEntity.ok(taskService.createTask(task));
//    }
    @PostMapping("/createTask")
    public String createTask(@ModelAttribute("task") Task task) {
    	taskService.createTask(task);
    	return "redirect:/";
    }
//    @PutMapping("/{id}")
//    public ResponseEntity<Task> updateTask(@PathVariable Long id, @RequestBody Task task) {
//        task.setId(id);
//        return ResponseEntity.ok(taskService.updateTask(task));
//    }
    @GetMapping("/showNewTaskForm")
    public String showNewTaskForm(Model model) {
    	Task task=new Task();
    	model.addAttribute("task",task);
    	return "newtask";
    }
    @GetMapping("/updateTask/{id}")
    public String updateTask(@PathVariable(value="id" )  long id, Model model) {
    	Task task=taskService.findTaskById(id);
    	model.addAttribute("task",task);
    	return "updatetask";
    }
//    @DeleteMapping("/{id}")
//    public ResponseEntity<Boolean> getAllTasks(@PathVariable Task id) {
//        taskService.deleteTask(id);
//        return ResponseEntity.ok(true);
//    }
    @GetMapping("/deleteTask/{id}")
    public String deleteTask(@PathVariable(value="id") long id) {
    	this.taskService.deleteTaskById(id);
    	return "redirect:/";
    }
}